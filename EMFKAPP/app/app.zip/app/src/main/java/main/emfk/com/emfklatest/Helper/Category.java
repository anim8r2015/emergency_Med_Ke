package main.emfk.com.emfklatest.Helper;

/**
 * Created by USER on 7/1/2016.
 */
public class Category {
    private String title;

    public Category() {
    }

    public Category(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String name) {
        this.title = name;
    }}
