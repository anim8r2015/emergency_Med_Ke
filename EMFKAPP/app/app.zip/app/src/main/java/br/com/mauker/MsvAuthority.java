package br.com.mauker;

/**
 * Created by root on 7/22/17.
 */

public class MsvAuthority {

    public static final String CONTENT_AUTHORITY = "main.emfk.com.emfklatest.searchhistorydatabase";

}
